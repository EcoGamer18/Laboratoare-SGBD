﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sem5P1
{
    public partial class Form1 : Form
    {
        static string connectionString = @"Data Source=DESKTOP-H9AHHS4\SQLEXPRESS;Initial Catalog=P72022;Integrated Security=True";
        SqlConnection cs = new SqlConnection(connectionString);
        SqlDataAdapter da1 = new SqlDataAdapter();
        SqlDataAdapter da2 = new SqlDataAdapter();
        DataSet ds = new DataSet();
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                cs.Open();
                string nume = txtNume.Text;
                string desc = txtDesc.Text;
                string pret = txtPret.Text;
                string an = txtAn.Text;
                string cod = txtCod.Text;
                SqlCommand cmd = new SqlCommand("INSERT INTO Parfumuri(nume_p,descriere_p,pret,an_lansare,cod_f) VALUES(@nume,@desc,@pret,@an,@cod)", cs);
                cmd.Parameters.AddWithValue("@nume", nume);
                cmd.Parameters.AddWithValue("@desc", desc);
                cmd.Parameters.AddWithValue("@pret", pret);
                cmd.Parameters.AddWithValue("@an", an);
                cmd.Parameters.AddWithValue("@cod", cod);
                cmd.ExecuteNonQuery();
                if (ds.Tables.Contains("Parfumuri"))
                {
                    ds.Tables["Parfumuri"].Clear();
                }
                da2.Fill(ds, "Parfumuri");
                dataGridView2.DataSource = ds.Tables["Paarfumuri"];
                cs.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                if (dataGridView2.SelectedRows.Count > 0)
                {
                    cs.Open();
                    string cod_parfum = dataGridView2.CurrentRow.Cells["cod_p"].Value.ToString();
                    string nume = txtNume.Text;
                    string desc = txtDesc.Text;
                    string pret = txtPret.Text;
                    string an = txtAn.Text;
                    string cod = txtCod.Text;
                    SqlCommand cmd = new SqlCommand("UPDATE Parfumuri SET nume_p = @nume ,descriere_p = @desc ,pret = @pret, an_lansare = @an ,cod_f = @cod WHERE cod_p = @cod_p", cs);
                    cmd.Parameters.AddWithValue("@nume", nume);
                    cmd.Parameters.AddWithValue("@desc", desc);
                    cmd.Parameters.AddWithValue("@pret", pret);
                    cmd.Parameters.AddWithValue("@cod", cod);
                    cmd.Parameters.AddWithValue("@an", an);
                    cmd.Parameters.AddWithValue("@cod_p", cod_parfum);
                    cmd.ExecuteNonQuery();
                    if (ds.Tables.Contains("Parfumuri"))
                    {
                        ds.Tables["Parfumuri"].Clear();
                    }
                    da2.Fill(ds, "Parfumuri");
                    dataGridView2.DataSource = ds.Tables["Parfumuri"];
                    cs.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                if (dataGridView2.SelectedRows.Count > 0)
                {
                    cs.Open();
                    string cod_p = dataGridView2.CurrentRow.Cells["cod_p"].Value.ToString();
                    SqlCommand cmd = new SqlCommand("DELETE FROM Parfumuri WHERE cod_p = @cod_p", cs);
                    cmd.Parameters.AddWithValue("@cod_p", cod_p);
                    cmd.ExecuteNonQuery();
                    if (ds.Tables.Contains("Parfumuri"))
                    {
                        ds.Tables["Parfumuri"].Clear();
                    }
                    da2.Fill(ds, "Parfumuri");
                    dataGridView2.DataSource = ds.Tables["Parfumuri"];
                    cs.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            cs.Open();
            SqlCommand cmd = new SqlCommand("Select * from Firme", cs);
            da1.SelectCommand = cmd;
            da1.Fill(ds, "Firme");
            dataGridView1.DataSource = ds.Tables["Firme"];
            cs.Close();
            
        }

        private void dataGridView1_SelectionChanged(object sender, EventArgs e)
        {
            if(dataGridView1.SelectedRows.Count > 0)
            {
                string cod_f = dataGridView1.CurrentRow.Cells["cod_f"].Value.ToString();
                cs.Open();
                SqlCommand cmd = new SqlCommand("Select * from Parfumuri where cod_f = @cod_f", cs);
                cmd.Parameters.AddWithValue("@cod_f", cod_f);
                da2.SelectCommand = cmd;
                if(ds.Tables.Contains("Parfumuri"))
                {
                    ds.Tables["Parfumuri"].Clear();
                }
                da2.Fill(ds, "Parfumuri");
                dataGridView2.DataSource = ds.Tables["Parfumuri"];
                cs.Close();
            }
        }
    }
}
